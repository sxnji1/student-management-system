# Student Management System with Docker Compose

## 🧩 Проектът включва:
- Java приложение за добавяне, изтриване и показване на студенти
- MySQL база данни
- Контейнеризация чрез Docker и Docker Compose

## 🏗 Как се стартира:

```bash
docker-compose up --build
