package com.example.sms;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n1. Add student");
            System.out.println("2. Remove student");
            System.out.println("3. List all students");
            System.out.println("0. Exit");
            System.out.print("Choose option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // consume newline

            switch (choice) {
                case 1 -> {
                    System.out.print("Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Age: ");
                    int age = scanner.nextInt();
                    Database.addStudent(new Student(0, name, age));
                }
                case 2 -> {
                    System.out.print("Student ID to remove: ");
                    int id = scanner.nextInt();
                    Database.removeStudent(id);
                }
                case 3 -> Database.getAllStudents().forEach(
                        s -> System.out.println(s.getId() + ": " + s.getName() + ", Age: " + s.getAge()));
                case 0 -> {
                    System.out.println("Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }
}
